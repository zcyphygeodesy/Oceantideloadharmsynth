全空间大地测量海潮负荷效应球谐综合Fortran代码
https://www.zcyphygeodesy.com/h-nd-44.html
[计算目标]
   利用全球海潮负荷球谐系数模型（cm），按负荷球谐综合算法，由给定经纬度正常高和时刻，预报瞬时海面潮高（cm），计算地面及地球外部计算点10种大地测量要素的海潮负荷效应。
   扩展与完善IERS2010第6、7章中的海潮负荷效应算法，实现全空间大地测量全要素海潮负荷效应统一解析计算。

[输出结果]
   瞬时潮高tdh（cm），全要素海潮负荷效应tdn(14)
   tdn(14)存放10种大地测量要素海潮负荷效应：高程异常（大地水准面mm）tdn(1)、地面重力⊙（μGal）tdn(2)、扰动重力（μGal）tdn(3)、地倾斜⊙（SW南向/西向mas）tdn(4) tdn(5)、垂线偏差（SW南向/西向mas）tdn(6) tdn(7)、水平位移⊙（EN东向/北向mm）tdn(8) tdn(9)、地面径向⊙（大地高mm）tdn(10)、地面正（常）高⊙（mm）tdn(11)、扰动重力梯度（径向10μE）tdn(12)和水平重力梯度（NW北向/西向10μE）tdn(13) tdn(14)的海潮负荷效应。
   计算点可以位于地面、低空、卫星、海洋或水下空间，上述标注⊙的要素，当且仅当计算点位与地球固连时有效。
   预先将两个地球物理模型读入内存后，每个计算点120阶全要素海潮负荷效应的计算时间约25ms。
[两个输入地球物理模型文件]
 （1）海潮负荷球谐系数模型FES2004S1.dat文件（IERS协议2010的FES2004海潮负荷模型格式）；
 （2）负荷勒夫数文件love_load_cm.dat（0~3600阶，来源于区域地面回弹计算器REAR1.0，2015）。

[测试入口程序]
   Otdloalharmsynth.f90
   输出文件reslt.txt记录：相对开始时间的天数，tdh，tdn(1:14)
[四个核心模块]
 （1）全球海洋潮高预报模块
   otidehsynth(mjd,BLH,tdh,fes,nn,maxn,GRS)
   输入：MJD, BLH(3)－计算时刻（MJD），计算点的纬度、经度（度小数）和正（常）高（m）
   输入：fes(nn,7)－海潮负荷球谐系数doodson,n,m,C+(cm),eps+,C-(cm),eps-。
   输入：GRS(6)－gm, ae, j2, omega, 1/f, 缺省值
   输入：maxn－海潮负荷球谐系数模型最大计算阶数。
   返回：tdh－MJD时刻(L,B)处海面潮高预报值（cm）。
 （2）重力位系数的海潮负荷直接影响计算模块
   OLoadDFlu(mjd,cnm,snm,maxn,fes,nn)
   由海潮负荷球谐系数模型计算位系数的海潮负荷直接影响。
   返回：cnm,snm－位系数的海潮负荷直接影响。
 （3）大地测量全要素海潮负荷效应计算模块
   LTideFlupnm(rln,maxn,cnm,snm,flv,tdn,GRS,pnm,dpt1,dpt2,gr)
   输入：rln(3)－计算点的球坐标（ITRS）
   输入：snm,maxn－位系数的海潮负荷直接影响。
   输入：flv(maxn,3)－负荷勒夫数。
   输入：pnm,dpt1,dpt2,gr－计算点处规格化连带勒让德函数pnm及其一、二阶导数dpt1,dpt2，正常重力gr
   返回：tdn(14)－全要素海潮负荷效应
 （4）规格化连带勒让德函数及其一、二阶导数模块
   BelPnmdt(pnm,dpt1,dpt2,maxn,t)
   计算规格化连带勒让德函数Pnm及其对θ一、二阶导数，t=cosθ。规格化Pnm采用改进的Belikov递推算法，一、二阶导数采用非奇异递推算法。
[八个辅助模块]
 （5）海潮主要分潮交点参数计算模块
   CalcTidefu(mjd,doodson,df,du)
   输入：doodson－分潮的Doodson常数，长整数
   返回：df,du－分潮的交点因子与交点订正角（°）
 （6）潮汐分潮相位偏差计算模块
   BiasTide(doodson,bias)
   返回：bias－分潮的相位偏差（°）
 （7）5个基本天文辐角计算模块
   ASTRO5(TIME,SHPNP) ! s, h, p, N, p'
 （8）MJD计算模块
   CAL2JD(IY,IM,ID,mjd,j)；来源IAU的SOFA库
 （9）椭球大地坐标变换为球坐标模块
   BLH_RLAT(GRS,BLH,RLAT)
 （10）正常重力位系数计算模块
   normdjn(GRS,djn)；输入GRS－gm,ae,j2,omega,1/f,缺省值
 （11）勒让德函数及导数计算模块
   Legendre(maxn,m,rlat,RLEG,DLEG)；PlmBar_d(p,dp,lmax,rlat)
 （12）ETideLoad格式日期tm转年月日时分秒
   tmcnt(tm,iyr,imo,idy,ihr,imn,sec)

[编译连接]
   Fortran固定格式代码，任何fortran编译器，无需任何外部连接库。
[算法公式]参见ETideLoad4.5参考说明书(https://www.zcyphygeodesy.com)
   8.4.1全球海潮负荷球谐系数模型构建方法
   8.2.2负荷形变场规格化球谐级数展开-球谐综合算法公式
   8.2.3规格化缔合勒让德函数及对θ导数

DOS可执行测试程序、全部地球物理模型和测试输入输出数据。